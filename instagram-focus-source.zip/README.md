# Instagram Focus

> **"Instagram as a communication tool, NOT an entertainment app."**

**Instagram Focus** is a private, on-device Android productivity tool designed for personal self-control. It creates an intelligent protection layer around the official Instagram app to eliminate addictive infinite scrolling, Reels, and Explore rabbit holes while preserving 100% of genuine personal communication.

---

## 🎯 The Core Philosophy

| ✅ Allowed Communication | ❌ Blocked Distractions |
| :--- | :--- |
| **Direct Messages (DMs)** (Inbox, Chats, Media, Voice Notes) | **Instagram Reels** (Endless short-video feed) |
| **Instagram Stories** (Updates from friends & close contacts) | **Explore Grid** (Algorithmic discovery rabbit holes) |
| **Follow Requests** (Reviewing, approving, declining) | **Endless Feed Scrolling** (Past caught-up / suggested posts) |
| **User Profiles** (Looking up contacts intentionally) | **Suggested Accounts & Content** |
| **Social Notifications** (Messages, mentions, follow requests) | **Promotional & Reel Push Notifications** |

---

## 🔒 Privacy & Security First

- **100% On-Device**: Zero external servers, zero cloud APIs, zero user analytics.
- **No Reverse Engineering**: No private Instagram APIs or session hijacking.
- **No Credentials**: Never asks for passwords, 2FA tokens, cookies, or account access.
- **Zero Logging of Private Content**: Notification and Accessibility scanners only evaluate structural markers and UI tags. Private message contents are never stored or logged.

---

## 🏗️ Architecture & Project Structure

The project follows Modern Android Clean Architecture + MVVM + Jetpack Compose + Material 3:

```
app/
 ├── data/
 │   ├── local/               # On-device SQLite helper for aggregate distraction counters
 │   ├── preferences/         # Jetpack DataStore for focus settings & temporary bypass timers
 │   └── repository/          # FocusSettingsRepository & StatisticsRepository
 │
 ├── domain/
 │   ├── model/               # ScreenType, RestrictionDecision, FocusSettings, BypassState
 │   ├── classifier/          # NodeSnapshot, InstagramAdapter, ScreenClassifier & heuristics
 │   ├── restriction/         # RestrictionEngine evaluating whitelist vs distraction rules
 │   └── usecase/             # ClassifyScreenUseCase, EvaluateRestrictionUseCase, etc.
 │
 ├── service/
 │   ├── FocusAccessibilityService.kt        # Low-overhead, debounced screen inspector & intervention
 │   ├── FocusNotificationListenerService.kt # Filters promotional reels notifications
 │   └── InstagramAdapter.kt                 # UI signatures, view IDs, and intent deep links
 │
 ├── ui/
 │   ├── MainActivity.kt      # Main entry point & Jetpack Navigation graph
 │   ├── onboarding/          # 4-step onboarding explaining philosophy, permissions & rules
 │   ├── dashboard/           # Master switch, allowed/blocked summary, stats, bypass controls
 │   ├── intervention/        # Calm intervention screen ("This section is blocked")
 │   ├── settings/            # Granular toggle controls for surfaces & strict mode
 │   ├── statistics/          # Today & weekly distraction protection metrics
 │   ├── debug/               # Live UI classifier simulator & rule inspector
 │   ├── components/          # Reusable Material 3 design system components
 │   └── theme/               # Calm productivity theme (Dark/Light mode support)
 │
 └── util/
     ├── PermissionUtils.kt   # System permission checks & settings deep links
     ├── InstagramIntents.kt  # Direct DM & notification intent launchers
     └── Debouncer.kt         # Event debouncing to guarantee low battery impact
```

---

## 📱 Installation & Setup Guide

### Prerequisites
- Android smartphone running Android 8.0 (API 26) or higher.
- Official Instagram app installed from Google Play Store.

### Step 1: Install the APK
1. Transfer `app-debug.apk` to your phone (via USB, Google Drive, or `adb install -r app-debug.apk`).
2. Tap the APK file on your phone and tap **Install** (allow "Install unknown apps" if prompted).

### Step 2: Grant Permissions (First-Run Onboarding)
Launch **Instagram Focus** and follow the onboarding flow to enable the 3 required Android capabilities:

1. **Accessibility Service (`Instagram Focus Filter`)**:
   - Go to `Settings -> Accessibility -> Downloaded Apps / Installed Apps -> Instagram Focus Filter`.
   - Toggle **ON** and confirm.
   - *Why needed*: Allows the app to detect when a Reels or Explore screen is opened in Instagram so it can intervene.
2. **Display Over Other Apps (`Draw Over Apps`)**:
   - Go to `Settings -> Apps -> Special App Access -> Display over other apps -> Instagram Focus`.
   - Toggle **ON**.
   - *Why needed*: Displays the calm intervention screen when a distraction surface is blocked.
3. **Notification Access (Optional)**:
   - Go to `Settings -> Apps -> Special App Access -> Notification Access -> Instagram Focus`.
   - Toggle **ON**.
   - *Why needed*: Suppresses push notifications tempting you to watch Reels while preserving DM notifications.

---

## 🧪 Testing & Verification Guide

| Test Scenario | Action in Instagram | Expected Behavior |
| :--- | :--- | :--- |
| **1. Direct Messages** | Tap DM icon or launch "Go to DMs" | ✅ **ALLOWED**: Chat, send messages, read messages freely. |
| **2. Instagram Stories** | Tap story bubbles at the top of Instagram | ✅ **ALLOWED**: Watch stories and reply to friends. |
| **3. Follow Requests** | Open follow requests tab | ✅ **ALLOWED**: Confirm or reject connection requests. |
| **4. User Profiles** | Search and open any friend's profile | ✅ **ALLOWED**: View account profile, bio, and posts. |
| **5. Reels Tab** | Tap the Reels bottom navigation icon | 🛑 **BLOCKED**: Returns back; Calm Intervention displays "Reels are disabled". |
| **6. Explore Grid** | Tap the magnifying glass icon | 🛑 **BLOCKED**: Intervenes immediately to prevent infinite browsing. |
| **7. Temporary Bypass** | Tap "10 min" bypass on dashboard | ⏱️ **PAUSED**: Instagram functions normally for 10 minutes, then auto-locks. |
| **8. Anti-Bypass Friction** | Toggle Focus Mode OFF | 🛡️ Prompts "Why are you turning Focus Mode off?" with quick bypass option. |
| **9. Debug Screen** | Open Debug Inspector from dashboard | 🔍 Test different Instagram screen snapshots live and inspect confidence scores. |

---

## 🔋 Performance & Battery Optimization
- **Zero background polling**: The service only wakes up when window events occur in `com.instagram.android`.
- **Event Debouncing**: Rapid scroll events are debounced with a 120ms window to minimize CPU usage.
- **Bounded Tree Depth**: Snapshot analysis is capped at depth 6 and 12 children per node, preventing UI lag and battery consumption.
